# Licensing of files in this directory

## Files available under the MIT license

The following files have been copied from https://github.com/shagu/pfQuest and with permission of the author are made available here under the MIT license.

You can find a copy of this license in the `MIT.txt` file of this directory.

### List of files

* fav.tga
* icon_alliance.tga
* icon_horde.tga
* loot_mono.tga
* node_cut.tga
* node.tga
* object_mono.tga
* route.tga
* slay_mono.tga
* startend.tga
* startendstart.tga
* tracker_clean.tga
* tracker_close.tga
* tracker_database.tga
* tracker_giver.tga
* tracker_quests.tga
* tracker_search.tga
* tracker_settings.tga

## All rights reserved

The licensing for all the files in this directory not mentioned above is unclear, please consider them "all rights reserved".
